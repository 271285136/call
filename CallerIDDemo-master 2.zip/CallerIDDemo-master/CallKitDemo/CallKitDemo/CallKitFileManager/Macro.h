//
//  Macro.h
//  CallKitDemo
//
//  Created by Johnson Rey on 2018/5/21.
//  Copyright © 2018年 Zimeng Rey. All rights reserved.
//

#ifndef Macro_h
#define Macro_h

// CallKitExtension bundle ID
#define ExtensionIdentifier @"com.liuf.CallKitDemo.JRCallKitExtension"
// app group id
#define AppGroupIdentifier @"group.com.liuf.Demo.Extension"

#define FileName @"CallDirectoryData"

#endif /* Macro_h */
