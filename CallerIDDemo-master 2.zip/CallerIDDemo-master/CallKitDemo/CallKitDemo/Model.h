//
//  Model.h
//  CallKitDemo
//
//  Created by Johnson Rey on 2018/5/17.
//  Copyright © 2018年 Zimeng Rey. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Model : NSObject

@property (nonatomic, strong) NSString * name;

@property (nonatomic, strong) NSString * number;

@end
